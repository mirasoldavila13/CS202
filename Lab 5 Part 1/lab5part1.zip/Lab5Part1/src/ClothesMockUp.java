import java.util.ArrayList;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ClothesMockUp extends Application{
		
	public static ArrayList<ClothingPieces> getHats(){
		//create a hat object
		Hat baseballHat1 = new Hat("Baseball Hat", "Multi-color hat", "baseballHat1.jpg", 22.56, Material.COTTON, "7 1/4", "Yes");
		Hat baseballHat2 = new Hat("Baseball Hat", "Multi-color hat", "baseballHat2.jpg", 22.56, Material.COTTON, "9 5/8", "Yes");
		Hat beanie1 = new Hat("Beanie", "Purple beanie", "beanie1.jpg", 10.95, Material.COTTON, "8 3/4", "Yes");
		Hat beanie2 = new Hat("Beanie", "Maroon beanie", "beanie2.jpg", 10.50, Material.COTTON, "7 1/2", "Yes");
		Hat beret1 = new Hat("Beret", "Red beret", "beret1.jpg", 30.05, Material.COTTON, "12 1/2", "NO");
		Hat beret2 = new Hat("Beret", "Black beret", "beret2.jpg", 30.50, Material.COTTON, "11", "No");
		Hat boater1 = new Hat("Boater", "Tri-color boater", "boater12.jpg", 20.75, Material.COTTON, "6 1/2", "No");
		Hat boater2 = new Hat("Boater", "Tri-color boater", "boater2.jpg", 20.50, Material.COTTON, "9 1/2", "No");
		Hat fedora1 = new Hat("Fedora", "Dark Brown fedora", "fedora1.jpg", 11.99, Material.COTTON, "7 1/2", "No");
		Hat fedora2 = new Hat("Fedora", "Light Brown fedora", "fedora2.jpg", 11.99, Material.COTTON, "6 3/4", "No");
		Hat gatsby1 = new Hat("Gatsby", "Tan gatsby", "Gatsby1.jpg", 10.50, Material.COTTON, "7 1/2", "Yes");
		Hat gatsby2 = new Hat("Gatsby", "Grey gatsby", "Gatsby1.jpg", 10.50, Material.COTTON, "6 5/8", "Yes");
		//hat1
		Hat topHat1 = new Hat("Top Hat", "Grey and Black", "TopHat1.jpg", 15.50, Material.COTTON, "7 7/8", "No");
		Hat topHat2 = new Hat("Top Hat", "Black and white", "TopHat2.png", 15.50, Material.COTTON, "8 7/8", "No");
		
		//add objects to the array
		ClothingPieces.getHats().add(baseballHat1);
		ClothingPieces.getHats().add(baseballHat2);
		ClothingPieces.getHats().add(beanie1);
		ClothingPieces.getHats().add(beanie2);
		ClothingPieces.getHats().add(beret1);
		ClothingPieces.getHats().add(beret2);
		ClothingPieces.getHats().add(boater1);
		ClothingPieces.getHats().add(boater2);
		ClothingPieces.getHats().add(fedora1);
		ClothingPieces.getHats().add(fedora2);
		ClothingPieces.getHats().add(gatsby1);
		ClothingPieces.getHats().add(gatsby2);
		ClothingPieces.getHats().add(topHat1);
		ClothingPieces.getHats().add(topHat2);
		
		//return
		return ClothingPieces.getHats();
	}
	
	public static ArrayList<ClothingPieces>  getTops(){
		Top blouse1 = new Top("Blouse","Blue blouse", "blouse1.jpg", 29.45, Material.COTTON, "Small", "Yes");
		Top blouse2 = new Top("Blouse","Nude blouse", "blouse2.jpg", 28.40, Material.COTTON, "Medium", "No");
		Top blouse3 = new Top("Blouse","White and black blouse", "blouse3.jpg", 29.40, Material.COTTON, "Large", "No");
		Top blouse4 = new Top("Blouse","Maroon blouse", "blouse4.jpg", 29.45, Material.COTTON, "X-Large", "No");
		Top blouse5 = new Top("Blouse","Red blouse", "blouse5.jpg", 30.00, Material.COTTON, "Small", "No");
		Top dressShirt1 = new Top("Dress Shirt","White and Black Dress Shirt", "dressShirt1.jpg", 35.65, Material.COTTON, "Medium", "Yes");
		Top dressShirt2 = new Top("Dress Shirt","Black Dress Shirt", "dressShirt2.jpg", 35.00, Material.COTTON, "Small", "Yes");
		Top dressShirt3 = new Top("Dress Shirt","Pink Dress Shirt", "dressShirt3.jpg", 30.00, Material.COTTON, "Large", "Yes");
		Top dressShirt4 = new Top("Dress Shirt","Grey Dress Shirt", "dressShirt4.jpg", 29.35, Material.COTTON, "X-Large", "Yes");
		Top flannel1 = new Top("Flannel","Multi-color flannel", "flannel1.jpg", 15.75, Material.COTTON, "Small", "Yes");
		Top flannel2 = new Top("Flannel","Multi-color flannel", "flannel2.jpg", 15.65, Material.COTTON, "Medium", "Yes");
		Top flannel3 = new Top("Flannel","Multi-color flannel", "flannel3.jpg", 15.99, Material.COTTON, "Large", "Yes");
		Top flannel4 = new Top("Flannel","Multi-color flannel", "flanne4.jpg", 16.00, Material.COTTON, "X-Large", "Yes");
		Top flannel5 = new Top("Flannel","Multi-color flannel", "flannel5.jpg", 16.25, Material.COTTON, "Small", "Yes");
		Top flannel6= new Top("Flannel","Multi-color flannel", "flannel6.jpg", 15.99, Material.COTTON, "Medium", "Yes");
		Top poloShirt1 = new Top("Polo Shirt","Teal Polo Shirt", "poloshirt1.jpg", 12.59, Material.COTTON, "Medium", "Yes");
		Top poloShirt2 = new Top("Polo Shirt","Pink Polo Shirt", "poloshirt2.jpg", 12.99, Material.COTTON, "Small", "Yes");
		Top poloShirt3 = new Top("Polo Shirt","Dark Blue Polo Shirt", "poloshirt3.jpg", 12.85, Material.COTTON, "Large", "Yes");
		Top poloShirt4 = new Top("Polo Shirt","Pink Polo Shirt", "poloshirt4.jpg", 12.00, Material.COTTON, "Large", "Yes");
		Top poloShirt5 = new Top("Polo Shirt","Forest Green Polo Shirt", "poloshirt5.jpg", 12.86, Material.COTTON, "Medium", "Yes");
		Top poloShirt6 = new Top("Polo Shirt","Stripe Polo Shirt", "poloshirt6.jpg", 13.99, Material.COTTON, "Large", "Yes");
		Top shirt1 = new Top("Shirt","Grey shirt", "shirt1.jpg", 15.99, Material.COTTON, "Large", "No");
		Top shirt2 = new Top("Shirt","Aqua shirt", "shirt2.jpg", 15.99, Material.COTTON, "Medium", "No");
		Top shirt3 = new Top("Shirt","Green shirt", "shirt3.jpg", 16.25, Material.COTTON, "Small", "No");
		Top shirt4 = new Top("Shirt","Light Pink shirt", "shirt4.jpg", 16.99, Material.COTTON, "Medium", "No");
		Top shirt5 = new Top("Shirt","White shirt", "shirt5.jpg", 16.99, Material.COTTON, "Small", "No");
		Top suitCombo1 = new Top("Suit","Black suit", "SuitCombo1.jpg", 32.56, Material.COTTON, "Small", "No");
		Top suitCombo2 = new Top("Suit","Black suit", "SuitCombo2.jpg", 35.99, Material.COTTON, "Small", "No");
		Top suitCombo3 = new Top("Suit","Grey suit", "SuitCombo3.jpg", 30.45, Material.COTTON, "Small", "No");
		Top suitCombo4 = new Top("Suit","Dark Grey suit", "SuitCombo4.jpg", 29.99, Material.COTTON, "Small", "No");
		
		//add objects to the array
		ClothingPieces.getTops().add(blouse1);
		ClothingPieces.getTops().add(blouse2);
		ClothingPieces.getTops().add(blouse3);
		ClothingPieces.getTops().add(blouse4);
		ClothingPieces.getTops().add(blouse5);
		ClothingPieces.getTops().add(dressShirt1);
		ClothingPieces.getTops().add(dressShirt2);
		ClothingPieces.getTops().add(dressShirt3);
		ClothingPieces.getTops().add(dressShirt4);
		ClothingPieces.getTops().add(flannel1);
		ClothingPieces.getTops().add(flannel2);
		ClothingPieces.getTops().add(flannel3);
		ClothingPieces.getTops().add(flannel4);
		ClothingPieces.getTops().add(flannel5);
		ClothingPieces.getTops().add(flannel6);
		ClothingPieces.getTops().add(poloShirt1);
		ClothingPieces.getTops().add(poloShirt2);
		ClothingPieces.getTops().add(poloShirt3);
		ClothingPieces.getTops().add(poloShirt4);
		ClothingPieces.getTops().add(poloShirt5);
		ClothingPieces.getTops().add(poloShirt6);
		ClothingPieces.getTops().add(shirt1);
		ClothingPieces.getTops().add(shirt2);
		ClothingPieces.getTops().add(shirt3);
		ClothingPieces.getTops().add(shirt4);
		ClothingPieces.getTops().add(shirt5);
		ClothingPieces.getTops().add(suitCombo1);
		ClothingPieces.getTops().add(suitCombo2);
		ClothingPieces.getTops().add(suitCombo3);
		ClothingPieces.getTops().add(suitCombo4);
		
		return ClothingPieces.getTops();
	}
	
	public static ArrayList<ClothingPieces>  getBottom(){
		//create bottom objects
		Bottom pants1 = new Bottom("Pants", "Maroon Pants", "pants1.jpg", 26.88, Material.COTTON, " ", " ");  //need waist and length measurements
		Bottom pants2 = new Bottom("Pants", "Jeans", "pants2.jpg", 30.99, Material.COTTON, " ", " ");  //need waist and length measurements
		Bottom pants3 = new Bottom("Pants", "Jeans", "pants3.jpg", 45.99, Material.COTTON, " ", " ");  //need waist and length measurements
		Bottom pants4 = new Bottom("Pants", "Jeans", "pants4.jpg", 32.99, Material.COTTON, " ", " ");  //need waist and length measurements
		Bottom short1 = new Bottom("Short", "White shorts", "short1.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom short2 = new Bottom("Short", "Green shorts", "short2.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom short3 = new Bottom("Short", "Jean shorts", "short3.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt1 = new Bottom("Skirt", "Black skirt", "skirt2.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt2 = new Bottom("Skirt", "Black skirt", "skirt3.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt3 = new Bottom("Skirt", "Grey skirt", "skirt4.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt4 = new Bottom("Skirt", "Floral skirt", "skirt5.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt5 = new Bottom("Skirt", "Floral skirt", "skirt6.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt6 = new Bottom("Skirt", "Beige skirt", "skirt7.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt7 = new Bottom("Skirt", "Black skirt", "skirt8.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom slack1 = new Bottom("Slack", "Grey slack", "slack1.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom slack2 = new Bottom("Slack", "Black slac", "slack2.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		
		//add objects to the array
		ClothingPieces.getBottoms().add(pants1);
		ClothingPieces.getBottoms().add(pants2);
		ClothingPieces.getBottoms().add(pants3);
		ClothingPieces.getBottoms().add(pants4);
		ClothingPieces.getBottoms().add(short1);
		ClothingPieces.getBottoms().add(short2);
		ClothingPieces.getBottoms().add(short3);
		ClothingPieces.getBottoms().add(skirt1);
		ClothingPieces.getBottoms().add(skirt2);
		ClothingPieces.getBottoms().add(skirt3);
		ClothingPieces.getBottoms().add(skirt4);
		ClothingPieces.getBottoms().add(skirt5);
		ClothingPieces.getBottoms().add(skirt6);
		ClothingPieces.getBottoms().add(skirt7);
		ClothingPieces.getBottoms().add(slack1);
		ClothingPieces.getBottoms().add(slack2);
		
		return ClothingPieces.getBottoms();
	}
	
	public static ArrayList<ClothingPieces> getShoes(){
		//create objects for shoes
		Shoes flat1 = new Shoes("Flats", "Maroon flats", "flats1.jpg", 17.99, Material.COTTON, 8, "Regular");
		Shoes flat2 = new Shoes("Flats", "Blacks flats", "flats2.jpg", 15.99, Material.COTTON, 6.5, "Wide");
		Shoes flat3 = new Shoes("Flats", "Black flats", "flats3.jpg", 22.50, Material.COTTON, 7.5, "Regular");
		Shoes heel1 = new Shoes("Heels", "Nude heels", "heels1.jpg", 18.23, Material.COTTON, 7, "Wide");
		Shoes heel2 = new Shoes("Heels", "Multi-color heels", "heels2.jpg", 15.00, Material.COTTON, 9.5, "Regular");
		Shoes heel3 = new Shoes("Heels", "Black heels", "heels3.jpg", 17.95, Material.COTTON, 8, "Regular");
		Shoes nike1 = new Shoes("Nike",  "Multi-color nike", "nike1.jpg", 45.99, Material.COTTON, 10.5, "Regular");
		Shoes nike2 = new Shoes("Nike",  "Multi-color nike", "nike2.jpg", 49.99, Material.COTTON, 12, "Regular");
		Shoes vans1 = new Shoes("Vans", "Multi-color vans", "vans1.jpg", 22.99, Material.COTTON, 12, "Regular");
		Shoes vans2 = new Shoes("Vans", "Multi-color vans", "vans2.jpg", 25.99, Material.COTTON, 4, "Regular");
		Shoes vans3 = new Shoes("Vans", "Multi-color vans", "vans3.jpg", 25.99, Material.COTTON, 8, "Regular");
		Shoes vans4 = new Shoes("Vans", "Multi-color vans", "vans4.jpg", 25.99, Material.COTTON, 8, "Regular");
		
		//add objects to the array
		ClothingPieces.getShoes().add(flat1);
		ClothingPieces.getShoes().add(flat2);
		ClothingPieces.getShoes().add(flat3);
		ClothingPieces.getShoes().add(heel1);
		ClothingPieces.getShoes().add(heel2);
		ClothingPieces.getShoes().add(heel3);
		ClothingPieces.getShoes().add(nike1);
		ClothingPieces.getShoes().add(nike2);
		ClothingPieces.getShoes().add(vans1);
		ClothingPieces.getShoes().add(vans2);
		ClothingPieces.getShoes().add(vans3);
		ClothingPieces.getShoes().add(vans4);
		
		return ClothingPieces.getShoes();
	}
	
		
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		//create a stage title
		primaryStage.setTitle("Fashion Maker");
		
		
		//create regular buttons and div
		Button changeHatButton = new Button("Change Hat");		
		 changeHatButton.setId("hat-button");
		Button changeTopButton = new Button("Change Top");
		changeTopButton.setId("top-button");
		Button changeBottomButton = new Button("Change Buttom");
		changeBottomButton.setId("bottom-button");
		Button changeShoeButton	= new Button("Change Shoes");
		changeShoeButton.setId("shoe-button");
		Button saveButton = new Button("Save Outfit");
		saveButton.setId("save-button");
		
		
			
		
		//create hBox for 3 button
		HBox hbox = new HBox(changeHatButton, changeTopButton, changeBottomButton, changeShoeButton, saveButton); 
		//set spacing and padding
		hbox.setSpacing(10);
		hbox.setPadding(new Insets(10));
						
		
		
		//create drop down buttons
		ChoiceBox<String> hatButton = new ChoiceBox<>();// dropdown box for hats
		ChoiceBox<String> topButton = new ChoiceBox<>();//dropdown box for tops
		ChoiceBox<String> bottomButton = new ChoiceBox<>();//drop down box for bottom
		ChoiceBox<String> shoeButton = new ChoiceBox<>(); // drop down box for shoes
		
		//a get items returns the ObservableList object which you can add items to
		hatButton.getItems().addAll("6 1/2", "6 3/4", "6 5/8", "7 1/2", "7 1/4", "7 5/8","8 3/4","8 7/8", "9 1/2", "9 5/8","11", "12 1/2");
		topButton.getItems().addAll("Small", "Medium", "Large", "X-Large");
		bottomButton.getItems().addAll("32x30", "27");
		shoeButton.getItems().addAll("6 Regular","6 Wide", "6.5 Regular", "6.5 Wide", "7 Regular", "7 Wide", "7.5 Regular",
		"7.5 Wide", "8 Regular", "8 Wide", "8.5 Regular", "8.5 Wide", "9 Regular", "9 Wide", "9.5 Regular", "9.5 Wide",
		"10 Regular", "10 Wide", "10.5 Regular", "10.5 Wide", "11 Regular", "11 Wide", "11.5 Regular", "11.5 Wide",
		"12 Regular", "12 Wide", "12.5 Regular", "12.5 Wide", "13 Regular", "13 Wide");
		
		//this should be in box for it can have decription
		//set default value
		//need the text file of each object ex: hat, top, bottom, shoes
		//each picture should return 
		hatButton.setValue("6 5/8");
		topButton.setValue("Medium");
		bottomButton.setValue("32x30");
		shoeButton.setValue("8.5 Regular");
		//Description of the image
		
		//create VBox 
		TilePane tile = new TilePane();
		//tile.setStyle("-fx-background-color: #663399;");
		VBox choicebox = new VBox(10);
		choicebox.getChildren().addAll(hatButton,topButton, bottomButton, shoeButton);
		choicebox.setPadding(new Insets(20, 20, 20, 20));
		tile.getChildren().add(choicebox);
		//choicebox.setAlignment(Pos.TOP_LEFT);
		//choicebox.setAccessibleHelp(Priority.ALWAYS);
		
		
		
		
		//add both vbox for regular button, and dropdown button and add hbox
		FlowPane flow = new FlowPane();
      	flow.setPadding(new Insets(10, 10, 10, 10));
		//flow.setStyle("-fx-background-color: #663399;");
      	flow.getChildren().addAll(hbox);
      	
      	
      	
      	BorderPane pane = new BorderPane();
      	//pane.setLeft(anchorpane);
      	//pane.setCenter(root);
      	//pane.setRight(grid);
      	pane.setRight(tile);
     	pane.setBottom(flow);
		
		
				
		
				//couldn't find a way to display the images
//		// load the image
//     	Image hatImage = new Image("/Lab5Part1/boater2.jpg");
//
//        // simple displays ImageView the image as is
//        ImageView image = new ImageView();
//        image.setImage(hatImage);
//
//
//        
        
    
		//usual code at the end of start
		Scene scene = new Scene(pane, 300, 250);
		String css = ClothesMockUp.class.getResource("style.css").toExternalForm();
		scene.getStylesheets().add(css);
		primaryStage.setWidth(415);
        primaryStage.setHeight(200);
		primaryStage.setScene(scene);
		primaryStage.show();
		
		
	}
	
	
	
	
	
}

public class Bottom extends ClothingPieces{
	String waist;// maybe this could be a double type 
	String length; // 33.4' maybe or maybe this could be a double type
	
	public Bottom(String name, String description, String imageFileName, double price, Material material, String waist,
			String length) {
		super(name, description, imageFileName, price, material);
		this.waist = waist;
		this.length = length;
	}
	
	
	
	
	
	
	
	//create objects of Bottoms jeans, leggings, shorts,  
}


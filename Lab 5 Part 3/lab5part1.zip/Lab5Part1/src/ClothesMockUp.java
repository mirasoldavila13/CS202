import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class ClothesMockUp extends Application implements EventHandler{
	//make the buttons global for the action handler can know what buttons
	Button newOutfit, loadOutfit, changeHatButton, changeTopButton, changeBottomButton, changeShoeButton, saveButton;
	Stage thestage;
	Scene scene1,scene2;
//	FlowPane pane3, pane4;
	
		
	public static ArrayList<ClothingPieces> getHats(){
		//create a hat object
		Hat baseballHat1 = new Hat("Baseball Hat", "Multi-color hat", "baseballHat1.jpg", 22.56, Material.COTTON, "7 1/4", "Yes");
		Hat baseballHat2 = new Hat("Baseball Hat", "Multi-color hat", "baseballHat2.jpg", 22.56, Material.COTTON, "9 5/8", "Yes");
		Hat beanie1 = new Hat("Beanie", "Purple beanie", "beanie1.jpg", 10.95, Material.COTTON, "8 3/4", "Yes");
		Hat beanie2 = new Hat("Beanie", "Maroon beanie", "beanie2.jpg", 10.50, Material.COTTON, "7 1/2", "Yes");
		Hat beret1 = new Hat("Beret", "Red beret", "beret1.jpg", 30.05, Material.COTTON, "12 1/2", "NO");
		Hat beret2 = new Hat("Beret", "Black beret", "beret2.jpg", 30.50, Material.COTTON, "11", "No");
		Hat boater1 = new Hat("Boater", "Tri-color boater", "boater12.jpg", 20.75, Material.COTTON, "6 1/2", "No");
		Hat boater2 = new Hat("Boater", "Tri-color boater", "boater2.jpg", 20.50, Material.COTTON, "9 1/2", "No");
		Hat fedora1 = new Hat("Fedora", "Dark Brown fedora", "fedora1.jpg", 11.99, Material.COTTON, "7 1/2", "No");
		Hat fedora2 = new Hat("Fedora", "Light Brown fedora", "fedora2.jpg", 11.99, Material.COTTON, "6 3/4", "No");
		Hat gatsby1 = new Hat("Gatsby", "Tan gatsby", "Gatsby1.jpg", 10.50, Material.COTTON, "7 1/2", "Yes");
		Hat gatsby2 = new Hat("Gatsby", "Grey gatsby", "Gatsby1.jpg", 10.50, Material.COTTON, "6 5/8", "Yes");
		//hat1
		Hat topHat1 = new Hat("Top Hat", "Grey and Black", "TopHat1.jpg", 15.50, Material.COTTON, "7 7/8", "No");
		Hat topHat2 = new Hat("Top Hat", "Black and white", "TopHat2.png", 15.50, Material.COTTON, "8 7/8", "No");
		
		//add objects to the array
		ClothingPieces.getHats().add(baseballHat1);
		ClothingPieces.getHats().add(baseballHat2);
		ClothingPieces.getHats().add(beanie1);
		ClothingPieces.getHats().add(beanie2);
		ClothingPieces.getHats().add(beret1);
		ClothingPieces.getHats().add(beret2);
		ClothingPieces.getHats().add(boater1);
		ClothingPieces.getHats().add(boater2);
		ClothingPieces.getHats().add(fedora1);
		ClothingPieces.getHats().add(fedora2);
		ClothingPieces.getHats().add(gatsby1);
		ClothingPieces.getHats().add(gatsby2);
		ClothingPieces.getHats().add(topHat1);
		ClothingPieces.getHats().add(topHat2);
		
		//return
		return ClothingPieces.getHats();
	}
	
	public static ArrayList<ClothingPieces>  getTops(){
		Top blouse1 = new Top("Blouse","Blue blouse", "blouse1.jpg", 29.45, Material.COTTON, "Small", "Yes");
		Top blouse2 = new Top("Blouse","Nude blouse", "blouse2.jpg", 28.40, Material.COTTON, "Medium", "No");
		Top blouse3 = new Top("Blouse","White and black blouse", "blouse3.jpg", 29.40, Material.COTTON, "Large", "No");
		Top blouse4 = new Top("Blouse","Maroon blouse", "blouse4.jpg", 29.45, Material.COTTON, "X-Large", "No");
		Top blouse5 = new Top("Blouse","Red blouse", "blouse5.jpg", 30.00, Material.COTTON, "Small", "No");
		Top dressShirt1 = new Top("Dress Shirt","White and Black Dress Shirt", "dressShirt1.jpg", 35.65, Material.COTTON, "Medium", "Yes");
		Top dressShirt2 = new Top("Dress Shirt","Black Dress Shirt", "dressShirt2.jpg", 35.00, Material.COTTON, "Small", "Yes");
		Top dressShirt3 = new Top("Dress Shirt","Pink Dress Shirt", "dressShirt3.jpg", 30.00, Material.COTTON, "Large", "Yes");
		Top dressShirt4 = new Top("Dress Shirt","Grey Dress Shirt", "dressShirt4.jpg", 29.35, Material.COTTON, "X-Large", "Yes");
		Top flannel1 = new Top("Flannel","Multi-color flannel", "flannel1.jpg", 15.75, Material.COTTON, "Small", "Yes");
		Top flannel2 = new Top("Flannel","Multi-color flannel", "flannel2.jpg", 15.65, Material.COTTON, "Medium", "Yes");
		Top flannel3 = new Top("Flannel","Multi-color flannel", "flannel3.jpg", 15.99, Material.COTTON, "Large", "Yes");
		Top flannel4 = new Top("Flannel","Multi-color flannel", "flanne4.jpg", 16.00, Material.COTTON, "X-Large", "Yes");
		Top flannel5 = new Top("Flannel","Multi-color flannel", "flannel5.jpg", 16.25, Material.COTTON, "Small", "Yes");
		Top flannel6= new Top("Flannel","Multi-color flannel", "flannel6.jpg", 15.99, Material.COTTON, "Medium", "Yes");
		Top poloShirt1 = new Top("Polo Shirt","Teal Polo Shirt", "poloshirt1.jpg", 12.59, Material.COTTON, "Medium", "Yes");
		Top poloShirt2 = new Top("Polo Shirt","Pink Polo Shirt", "poloshirt2.jpg", 12.99, Material.COTTON, "Small", "Yes");
		Top poloShirt3 = new Top("Polo Shirt","Dark Blue Polo Shirt", "poloshirt3.jpg", 12.85, Material.COTTON, "Large", "Yes");
		Top poloShirt4 = new Top("Polo Shirt","Pink Polo Shirt", "poloshirt4.jpg", 12.00, Material.COTTON, "Large", "Yes");
		Top poloShirt5 = new Top("Polo Shirt","Forest Green Polo Shirt", "poloshirt5.jpg", 12.86, Material.COTTON, "Medium", "Yes");
		Top poloShirt6 = new Top("Polo Shirt","Stripe Polo Shirt", "poloshirt6.jpg", 13.99, Material.COTTON, "Large", "Yes");
		Top shirt1 = new Top("Shirt","Grey shirt", "shirt1.jpg", 15.99, Material.COTTON, "Large", "No");
		Top shirt2 = new Top("Shirt","Aqua shirt", "shirt2.jpg", 15.99, Material.COTTON, "Medium", "No");
		Top shirt3 = new Top("Shirt","Green shirt", "shirt3.jpg", 16.25, Material.COTTON, "Small", "No");
		Top shirt4 = new Top("Shirt","Light Pink shirt", "shirt4.jpg", 16.99, Material.COTTON, "Medium", "No");
		Top shirt5 = new Top("Shirt","White shirt", "shirt5.jpg", 16.99, Material.COTTON, "Small", "No");
		Top suitCombo1 = new Top("Suit","Black suit", "SuitCombo1.jpg", 32.56, Material.COTTON, "Small", "No");
		Top suitCombo2 = new Top("Suit","Black suit", "SuitCombo2.jpg", 35.99, Material.COTTON, "Small", "No");
		Top suitCombo3 = new Top("Suit","Grey suit", "SuitCombo3.jpg", 30.45, Material.COTTON, "Small", "No");
		Top suitCombo4 = new Top("Suit","Dark Grey suit", "SuitCombo4.jpg", 29.99, Material.COTTON, "Small", "No");
		
		//add objects to the array
		ClothingPieces.getTops().add(blouse1);
		ClothingPieces.getTops().add(blouse2);
		ClothingPieces.getTops().add(blouse3);
		ClothingPieces.getTops().add(blouse4);
		ClothingPieces.getTops().add(blouse5);
		ClothingPieces.getTops().add(dressShirt1);
		ClothingPieces.getTops().add(dressShirt2);
		ClothingPieces.getTops().add(dressShirt3);
		ClothingPieces.getTops().add(dressShirt4);
		ClothingPieces.getTops().add(flannel1);
		ClothingPieces.getTops().add(flannel2);
		ClothingPieces.getTops().add(flannel3);
		ClothingPieces.getTops().add(flannel4);
		ClothingPieces.getTops().add(flannel5);
		ClothingPieces.getTops().add(flannel6);
		ClothingPieces.getTops().add(poloShirt1);
		ClothingPieces.getTops().add(poloShirt2);
		ClothingPieces.getTops().add(poloShirt3);
		ClothingPieces.getTops().add(poloShirt4);
		ClothingPieces.getTops().add(poloShirt5);
		ClothingPieces.getTops().add(poloShirt6);
		ClothingPieces.getTops().add(shirt1);
		ClothingPieces.getTops().add(shirt2);
		ClothingPieces.getTops().add(shirt3);
		ClothingPieces.getTops().add(shirt4);
		ClothingPieces.getTops().add(shirt5);
		ClothingPieces.getTops().add(suitCombo1);
		ClothingPieces.getTops().add(suitCombo2);
		ClothingPieces.getTops().add(suitCombo3);
		ClothingPieces.getTops().add(suitCombo4);
		
		return ClothingPieces.getTops();
	}
	
	public static ArrayList<ClothingPieces>  getBottom(){
		//create bottom objects
		Bottom pants1 = new Bottom("Pants", "Maroon Pants", "pants1.jpg", 26.88, Material.COTTON, " ", " ");  //need waist and length measurements
		Bottom pants2 = new Bottom("Pants", "Jeans", "pants2.jpg", 30.99, Material.COTTON, " ", " ");  //need waist and length measurements
		Bottom pants3 = new Bottom("Pants", "Jeans", "pants3.jpg", 45.99, Material.COTTON, " ", " ");  //need waist and length measurements
		Bottom pants4 = new Bottom("Pants", "Jeans", "pants4.jpg", 32.99, Material.COTTON, " ", " ");  //need waist and length measurements
		Bottom short1 = new Bottom("Short", "White shorts", "short1.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom short2 = new Bottom("Short", "Green shorts", "short2.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom short3 = new Bottom("Short", "Jean shorts", "short3.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt1 = new Bottom("Skirt", "Black skirt", "skirt2.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt2 = new Bottom("Skirt", "Black skirt", "skirt3.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt3 = new Bottom("Skirt", "Grey skirt", "skirt4.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt4 = new Bottom("Skirt", "Floral skirt", "skirt5.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt5 = new Bottom("Skirt", "Floral skirt", "skirt6.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt6 = new Bottom("Skirt", "Beige skirt", "skirt7.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom skirt7 = new Bottom("Skirt", "Black skirt", "skirt8.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom slack1 = new Bottom("Slack", "Grey slack", "slack1.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		Bottom slack2 = new Bottom("Slack", "Black slac", "slack2.jpg", 16.99, Material.COTTON, ""," "); //need waist and length measurements
		
		//add objects to the array
		ClothingPieces.getBottoms().add(pants1);
		ClothingPieces.getBottoms().add(pants2);
		ClothingPieces.getBottoms().add(pants3);
		ClothingPieces.getBottoms().add(pants4);
		ClothingPieces.getBottoms().add(short1);
		ClothingPieces.getBottoms().add(short2);
		ClothingPieces.getBottoms().add(short3);
		ClothingPieces.getBottoms().add(skirt1);
		ClothingPieces.getBottoms().add(skirt2);
		ClothingPieces.getBottoms().add(skirt3);
		ClothingPieces.getBottoms().add(skirt4);
		ClothingPieces.getBottoms().add(skirt5);
		ClothingPieces.getBottoms().add(skirt6);
		ClothingPieces.getBottoms().add(skirt7);
		ClothingPieces.getBottoms().add(slack1);
		ClothingPieces.getBottoms().add(slack2);
		//return
		return ClothingPieces.getBottoms();
	}
	
	public static ArrayList<ClothingPieces> getShoes(){
		//create objects for shoes
		Shoes flat1 = new Shoes("Flats", "Maroon flats", "flats1.jpg", 17.99, Material.COTTON, 8, "Regular");
		Shoes flat2 = new Shoes("Flats", "Blacks flats", "flats2.jpg", 15.99, Material.COTTON, 6.5, "Wide");
		Shoes flat3 = new Shoes("Flats", "Black flats", "flats3.jpg", 22.50, Material.COTTON, 7.5, "Regular");
		Shoes heel1 = new Shoes("Heels", "Nude heels", "heels1.jpg", 18.23, Material.COTTON, 7, "Wide");
		Shoes heel2 = new Shoes("Heels", "Multi-color heels", "heels2.jpg", 15.00, Material.COTTON, 9.5, "Regular");
		Shoes heel3 = new Shoes("Heels", "Black heels", "heels3.jpg", 17.95, Material.COTTON, 8, "Regular");
		Shoes nike1 = new Shoes("Nike",  "Multi-color nike", "nike1.jpg", 45.99, Material.COTTON, 10.5, "Regular");
		Shoes nike2 = new Shoes("Nike",  "Multi-color nike", "nike2.jpg", 49.99, Material.COTTON, 12, "Regular");
		Shoes vans1 = new Shoes("Vans", "Multi-color vans", "vans1.jpg", 22.99, Material.COTTON, 12, "Regular");
		Shoes vans2 = new Shoes("Vans", "Multi-color vans", "vans2.jpg", 25.99, Material.COTTON, 4, "Regular");
		Shoes vans3 = new Shoes("Vans", "Multi-color vans", "vans3.jpg", 25.99, Material.COTTON, 8, "Regular");
		Shoes vans4 = new Shoes("Vans", "Multi-color vans", "vans4.jpg", 25.99, Material.COTTON, 8, "Regular");
		
		//add objects to the array
		ClothingPieces.getShoes().add(flat1);
		ClothingPieces.getShoes().add(flat2);
		ClothingPieces.getShoes().add(flat3);
		ClothingPieces.getShoes().add(heel1);
		ClothingPieces.getShoes().add(heel2);
		ClothingPieces.getShoes().add(heel3);
		ClothingPieces.getShoes().add(nike1);
		ClothingPieces.getShoes().add(nike2);
		ClothingPieces.getShoes().add(vans1);
		ClothingPieces.getShoes().add(vans2);
		ClothingPieces.getShoes().add(vans3);
		ClothingPieces.getShoes().add(vans4);
		//return
		return ClothingPieces.getShoes();
	}
	
		
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {

		/* The first Stage is the main menu, as shown below, with two buttons, "New Outfit" and "Load Outfit".
"New Outfit" should bring up the second Stage and allow the user to modify the outfit using the JavaFX controls and 
save the outfit to a file with the format of your choice. "Load Outfit" should bring up the file chooser dialog 
and allow the user to pick an outfit save file. Your application should then load the file and display the user 
created outfit, with the correct ClothingPiece and sizes in the ComboBoxes.*/

		//stage1
		thestage = primaryStage;
		//Stage firstStage = new Stage();
		Label mainMenu = new Label("Fashion Maker");
		mainMenu.setId("mainmenu");
		final FileChooser fileChooser = new FileChooser();
		
		newOutfit = new Button("New Outfit");
		newOutfit.setId("newoutfit-button");
		newOutfit.setOnAction(e -> thestage.setScene(scene2));// once user clicks the new outfit button it will change to scene 2 where they can customize their outfits
		newOutfit.setOnMouseEntered(event -> {
			newOutfit.setTextFill(Color.ORANGERED);//color of the text when mouse hovers will be orange-red
		});
		
		newOutfit.setOnMouseExited(event -> {
			newOutfit.setTextFill(Color.RED);//once mouse moves away from the button the color will be red
		});
		
		
		loadOutfit = new Button("Load Outfit");
		loadOutfit.setId("loadoutfit-button");
		loadOutfit.setOnAction(this);
		loadOutfit.setOnMouseEntered(event -> {
			loadOutfit.setTextFill(Color.CRIMSON);//once mouse hovers the color of the text will be crimson
		});
		
		loadOutfit.setOnMouseExited(event -> {
			loadOutfit.setTextFill(Color.FUCHSIA);//once the mouse moves away from the button the text will change to the color fuchsia
		});
		

		VBox outfits = new VBox(10);

		outfits.setSpacing(10);
		outfits.setPadding(new Insets(10, 10, 10, 10));
		outfits.getChildren().addAll(mainMenu, newOutfit, loadOutfit);
		outfits.setAlignment(Pos.CENTER);
	
		
		Image fashion = new Image("fash4.jpg");
		// simple displays ImageView the image as is
		ImageView image1 = new ImageView();//image will be displayed with the two buttons(newOutfit and loadOutfit)
		image1.setImage(fashion);


		Polygon p = new Polygon();

		p.setLayoutX(100);
		p.setLayoutY(50);
		p.getPoints().add(50.0);
		p.getPoints().add(0.0);
		p.getPoints().add(100.0);
		p.getPoints().add(100.0);
		p.getPoints().add(0.0);
		p.getPoints().add(100.0);

		p.setFill(new ImagePattern(fashion, 0, 1.05, 1, 1, true));

		AnchorPane anchor = new AnchorPane(p, outfits);



		FlowPane root = new FlowPane();
		root.getChildren().addAll(p,anchor);
		root.setId("anchorpane");
		root.setAlignment(Pos.CENTER);
		//root.setCenter(anchor);       




		scene1 = new Scene(root, 350, 300);
		String css1 = ClothesMockUp.class.getResource("myStyle.css").toExternalForm();
		scene1.getStylesheets().add(css1);





		//stage2



		//create a stage title
		primaryStage.setTitle("Fashion Maker");
			
		//create regular buttons and div
		changeHatButton = new Button("Change Hat");		
		changeHatButton.setId("hat-button");
		changeHatButton.setOnAction(this); // every time the button is click it will change the images
		changeHatButton.setOnMouseEntered(event -> {
			changeHatButton.setTextFill(Color.BEIGE);//once mouse hovers the change hat button the color text will be  beige
		});
		
		changeHatButton.setOnMouseExited(event -> {
			changeHatButton.setTextFill(Color.DARKRED);//once mouse moves away from the change hat button the color text will be dark red
		});
		
		
		changeTopButton = new Button("Change Top");
		changeTopButton.setId("top-button");
		changeTopButton.setOnAction(this);// every time the button is click it will change the images
		changeTopButton.setOnMouseEntered(event ->{// once mouse hovers the change top button the color of the text will change to aqua
			changeTopButton.setTextFill(Color.AQUA);
		});
		
		changeTopButton.setOnMouseExited(event -> {// once the mouse moves away from the change top button the color will change to gold
			changeTopButton.setTextFill(Color.GOLD);
		});
		
		changeBottomButton = new Button("Change Buttom");
		changeBottomButton.setId("bottom-button");
		changeBottomButton.setOnAction(this);// every time the button is click it will change the images
		changeBottomButton.setOnMouseEntered(event -> {
			changeBottomButton.setTextFill(Color.SPRINGGREEN);// once the mouse hovers over the change bottom button it the color of the text will change to spring green
		});
		
		changeBottomButton.setOnMouseExited(event -> {
			changeBottomButton.setTextFill(Color.SNOW);//once the mouse moves away from the change bottom button the color will change to snow
		});
		
		changeShoeButton = new Button("Change Shoes");
		changeShoeButton.setId("shoe-button");
		changeShoeButton.setOnAction(this);// every time the button is click it will change the images
		changeShoeButton.setOnMouseEntered(event -> {
			changeShoeButton.setTextFill(Color.CHARTREUSE);//change the color when you hover
		});
		
		changeShoeButton.setOnMouseExited(event -> {
			changeShoeButton.setTextFill(Color.KHAKI);
		});
		
		saveButton = new Button("Save Outfit");// don't forget to add a text color
		saveButton.setId("save-button");//delete the other setonaction
		saveButton.setOnAction(this);// every time the button is click it will save the outfits the user picked out
//		saveButton.setOnAction(new EventHandler<ActionEvent>(){
//			@Override
//			public void handle(ActionEvent event){
//				System.out.println("How is it going");//testing if this action event works
//				FileChooser fileChooser = new FileChooser();
//	            fileChooser.setTitle("Save Image");
	            //System.out.println(pic.getId());//need to find out what pic is for the user can save their outfits
//	            File file = fileChooser.showSaveDialog(thestage);
////	            if (file != null) {
////	                try {
////	                    ImageIO.write(SwingFXUtils.fromFXImage(pic.getImage(),
////	                        null), "png", file);
////	                } catch (IOException ex) {
////	                    System.out.println(ex.getMessage());
////	                }
////	            }
//			}	
//		});




		//create hBox for the 5 buttons
		HBox hbox = new HBox(changeHatButton, changeTopButton, changeBottomButton, changeShoeButton, saveButton); 
		//set spacing and padding
		hbox.setSpacing(10);
		hbox.setPadding(new Insets(10));

			

		//create drop down buttons
		ChoiceBox<String> hatButton = new ChoiceBox<>();// dropdown box for hats
		ChoiceBox<String> topButton = new ChoiceBox<>();//dropdown box for tops
		ChoiceBox<String> bottomButton = new ChoiceBox<>();//drop down box for bottom
		ChoiceBox<String> shoeButton = new ChoiceBox<>(); // drop down box for shoes

		//a get items returns the ObservableList object which you can add items to
		hatButton.getItems().addAll("6 1/2", "6 3/4", "6 5/8", "7 1/2", "7 1/4", "7 5/8","8 3/4","8 7/8", "9 1/2", "9 5/8","11", "12 1/2");
		topButton.getItems().addAll("Small", "Medium", "Large", "X-Large");
		bottomButton.getItems().addAll("32x30", "27");
		shoeButton.getItems().addAll("6 Regular","6 Wide", "6.5 Regular", "6.5 Wide", "7 Regular", "7 Wide", "7.5 Regular",
				"7.5 Wide", "8 Regular", "8 Wide", "8.5 Regular", "8.5 Wide", "9 Regular", "9 Wide", "9.5 Regular", "9.5 Wide",
				"10 Regular", "10 Wide", "10.5 Regular", "10.5 Wide", "11 Regular", "11 Wide", "11.5 Regular", "11.5 Wide",
				"12 Regular", "12 Wide", "12.5 Regular", "12.5 Wide", "13 Regular", "13 Wide");

		
		
		//create the text for each choicebox --- 
		Text hat = new Text("Hat");
		hat.setStyle("-fx-font-size: 25");//need to change the text color of the text "Hat"
		Text top = new Text("Top: ");
		top.setStyle("-fx-font-size: 25");
		Text bottom = new Text("Bottom: ");
		bottom.setStyle("-fx-font-size: 25");
		Text shoe = new Text("Shoes: ");
		shoe.setStyle("-fx-font-size: 25");
		Text description = new Text("Description: ");//description for the immages
		description.setStyle("-fx-font-size: 25");
		
		//create the default value for each choice box which will display with their proper text
		hatButton.setValue("6 5/8");
		topButton.setValue("Medium");
		bottomButton.setValue("32x30");
		shoeButton.setValue("8.5 Regular");
		//Description of the image

		//create VBox 
		TilePane tile = new TilePane();
		tile.setStyle("-fx-background-color: #663399;");
		VBox choicebox = new VBox(10);
		choicebox.getChildren().addAll(hat,hatButton,top, topButton, bottom, bottomButton, shoe, shoeButton);
		choicebox.setPadding(new Insets(20, 20, 20, 20));
		tile.getChildren().add(choicebox);
		
		
		//add both vbox for regular button, and dropdown button and add hbox
		FlowPane flow = new FlowPane();
		flow.setPadding(new Insets(10, 10, 10, 10));
		flow.setStyle("-fx-background-color: #663399;");
		flow.getChildren().addAll(hbox);


		// load the image
		Pane image = new HBox(10);
		image.setPadding(new Insets(10, 10, 10, 10));

		//ClothingPieces clothes = ClothingPieces();
		Image hatImage = new Image("boater2.jpg");
		Image topImage = new Image("blouse1.jpg");
		Image bottomImage = new Image("skirt8.jpg");
		Image shoeImage = new Image("flats2.jpg");
		image.getChildren().addAll(new ImageView(hatImage), new ImageView(topImage), new ImageView(bottomImage), new ImageView(shoeImage));
		//need to connect buttons with image
		
		BorderPane pane = new BorderPane();
		pane.setRight(tile);
		pane.setBottom(flow);
		pane.getChildren().add(image);


		//usual code at the end of start
		scene2 = new Scene(pane, 500, 650);
		String css = ClothesMockUp.class.getResource("style.css").toExternalForm();
		scene2.getStylesheets().add(css);
		
		thestage.setScene(scene1);//default
		thestage.show();
	}
	//when user clicks on the button it will result in the following
	@Override
	public void handle(Event event) {
		if(event.getSource()== loadOutfit){
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Open Resource File");
			fileChooser.showOpenDialog(thestage);
		}
			
		if(event.getSource() == changeHatButton){
			System.out.println("Whats up this is the hat button");
		//need to comebine the arraylist for hat with the imageview
		}
		
		if(event.getSource()== changeTopButton){
			System.out.println("This is the top button");
			//need to combine the arraylist for tops with the image view 
			//reminder need to also display the name of image
		}
		
		if(event.getSource()== changeBottomButton){
			System.out.println("This is the bottom button");
		}
		
		if(event.getSource() == changeShoeButton){
			System.out.println("This is the shoe Button");
		}
		
		if(event.getSource() == saveButton){
			System.out.println("This is the save button");
		}
		
	}
}

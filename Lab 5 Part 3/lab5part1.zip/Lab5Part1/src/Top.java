public class Top extends ClothingPieces{
	String size; //small, medium, large, x-large
	String hasButton;
	
	public Top(String name, String description, String imageFileName, double price, Material material, String size,
			String hasButton) {
		super(name, description, imageFileName, price, material);
		this.size = size;
		this.hasButton = hasButton;
	}
	
	
	
	
	
	
	
	
	
	//create objects of tops shirts, flannels, blouse, Dress shirt, Polo shirt, Plaid shirt

}

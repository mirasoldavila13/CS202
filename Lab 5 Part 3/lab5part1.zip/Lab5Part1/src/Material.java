
public enum Material {
	
	COTTON, SILK, NYLON, LYCA;
}
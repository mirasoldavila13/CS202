public class Shoes extends ClothingPieces{
	double shoeSize; //yes this stays double 
	String shoeWidth; // regular or wide 
	
	public Shoes(String name, String description, String imageFileName, double price, Material material,
			double shoeSize, String shoeWidth) {
		super(name, description, imageFileName, price, material);
		this.shoeSize = shoeSize;
		this.shoeWidth = shoeWidth;
	}
	
	
	
	
	
	//create objects of shoes flats, converse, vans, heels, nikes
}

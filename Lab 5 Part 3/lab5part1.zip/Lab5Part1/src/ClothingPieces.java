import java.util.ArrayList;

public class ClothingPieces {
	//outfit has a description
	String name;
	String description;
	String imageFileName; // (used to load the images)
	static ArrayList<ClothingPieces> hats = new ArrayList<ClothingPieces>();//array of hats
	static ArrayList<ClothingPieces> tops = new ArrayList<ClothingPieces>();
	static ArrayList<ClothingPieces> bottoms = new ArrayList<ClothingPieces>();
	static ArrayList<ClothingPieces> shoes = new ArrayList<ClothingPieces>();
	double price; //price of the clothes
	private final  Material material; 
	
	
	
	public ClothingPieces(String name, String description, String imageFileName, double price, Material material) {
		super();
		this.name = name;
		this.description = description;
		this.imageFileName = imageFileName;
		this.price = price;
		this.material = material;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public  String getImageFileName() {
		return imageFileName;
	}

	public void setImageFileName(String imageFileName) {
		this.imageFileName = imageFileName;
	}

	

	public static ArrayList<ClothingPieces> getHats() {
		return hats;
	}



	public static void setHats(ArrayList<ClothingPieces> hats) {
		ClothingPieces.hats = hats;
	}



	public static ArrayList<ClothingPieces> getTops() {
		return tops;
	}



	public static void setTops(ArrayList<ClothingPieces> tops) {
		ClothingPieces.tops = tops;
	}



	public static ArrayList<ClothingPieces> getBottoms() {
		return bottoms;
	}



	public static void setBottoms(ArrayList<ClothingPieces> bottoms) {
		ClothingPieces.bottoms = bottoms;
	}



	public static ArrayList<ClothingPieces> getShoes() {
		return shoes;
	}



	public static void setShoes(ArrayList<ClothingPieces> shoes) {
		ClothingPieces.shoes = shoes;
	}



	@Override
	public String toString() {
		return "ClothingPieces [name=" + name + ", description=" + description + ", imageFileName=" + imageFileName
				+ ", price=" + price + ", material=" + material + "]";
	}



	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Material getMaterial() {
		return material;
	}



//	public enum Material{
//		COTTON, SILK, NYLON, LYCA
//	}
	
	
	public  ClothingPieces(Material material){
		this.material = material;
	}
	
	public void clothes(){
		switch(material){
		case COTTON:
			//something here
			System.out.println("It contains the matieral cotton");
			break;
		case SILK:
			//something here
			System.out.println("It contains the matieral silk");
			break;
		case NYLON:
			//something here
			System.out.println("It contains the matieral nylon");
			break;
		case LYCA:
			//something here
			System.out.println("It contains the matieral lyca");
			break;
		}
	}
	
	
	
	public static void main(String[] args){
		ClothingPieces cotton = new ClothingPieces(Material.COTTON);
		cotton.clothes();
		ClothingPieces silk = new ClothingPieces(Material.SILK);
		silk.clothes();
		ClothingPieces nylon = new ClothingPieces(Material.NYLON);
		nylon.clothes();
		ClothingPieces lyca = new ClothingPieces(Material.LYCA);
		lyca.clothes();
	
	}
}

import java.util.ArrayList;

public class Hat extends ClothingPieces{
	String diameter;
	String isAdjustable;
	
	public Hat(String name, String description, String imageFileName, double price, Material material, String diameter,
			String isAdjustable) {
		super(name, description, imageFileName, price, material);
		this.diameter = diameter;
		this.isAdjustable = isAdjustable;
	}
	
	
	
		
	
	
	//create objects of hats sombrero, beanie, Bicorne, Boater,  Fedora, Fascinator, Gatsby, Top hat, 
	
	/*
	ArrayList<Hat> hats = new ArrayList<Hat>(); //maybe name it something else
	
	//Hat hat1 = new Hat(""); // do hats last
	
	ArrayList<Top> shirt = new ArrayList<Top>();
	Top flannel = new Top("small", "yes");// has button
	Top blouse = new Top("Medium", "no"); //no buttom
	Top poloShirt = new Top("large", "yes");
	//maybe create more shirts
	
	ArrayList<Bottom> bottom = new ArrayList<Bottom>;
	Bottom jean4 = new Bottom("26.5", "35");// guy clothes are easier when it comes to pants
*/
	
}
